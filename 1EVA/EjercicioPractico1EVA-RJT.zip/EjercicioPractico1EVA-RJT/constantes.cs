﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioPractico1EVA_RJT
{
    public static class constantes
    {

        //se declaran las constantes de velocidad

        public static double VELOCIDAD_ANDANDO = 05;
        public static double VELOCIDAD_PATINETE = 25;

        public static double VELOCIDAD_BICICLETA = 20;
        public static double VELOCIDAD_COCHE = 75;
       

    }
}
